package tests

//easyjson:json
type MembersEscaped struct {
	A string `json:"漢語"`
}
