Docs: https://godoc.org/github.com/josharian/intern

See also [Go issue 5160](https://golang.org/issue/5160).

License: MIT
