function blur() {
    this.blur();
    return true;
}
