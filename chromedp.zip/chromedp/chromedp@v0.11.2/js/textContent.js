function textContent() {
    return this.textContent;
}
